#!/usr/bin/env bash
set -e
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

if [[ "$ALL_PROXY" == socks://* ]]; then
    export ALL_PROXY="socks5://${ALL_PROXY#socks://}"
fi
if [[ "$all_proxy" == socks://* ]]; then
    export all_proxy="socks5://${all_proxy#socks://}"
fi

exec "$APP_DIR/douyu_monitor_native" "$@"
