#!/usr/bin/env bash
set -e
echo "正在卸载斗鱼监控..."
rm -rf "$HOME/.local/opt/DouyuMonitor"
rm -f "$HOME/.local/share/applications/douyu-monitor.desktop"
rm -f "$HOME/桌面/douyu-monitor.desktop" 2>/dev/null || true
rm -f "$HOME/Desktop/douyu-monitor.desktop" 2>/dev/null || true
for size in 16 24 32 48 64 128 256 512; do
    rm -f "$HOME/.local/share/icons/hicolor/${size}x${size}/apps/douyu-monitor.png"
done
update-desktop-database "$HOME/.local/share/applications/" 2>/dev/null || true
echo "已彻底清除斗鱼监控及其快捷方式。"
