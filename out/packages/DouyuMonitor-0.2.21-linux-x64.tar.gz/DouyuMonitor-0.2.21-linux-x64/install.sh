#!/usr/bin/env bash
set -e
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="$HOME/.local/opt/DouyuMonitor"

echo "正在安装斗鱼监控到 $TARGET_DIR ..."
mkdir -p "$TARGET_DIR"
cp -r "$SRC_DIR/douyu_monitor_native" "$TARGET_DIR/"
cp -r "$SRC_DIR/streamget_service" "$TARGET_DIR/"
cp -r "$SRC_DIR/douyu_monitor.png" "$TARGET_DIR/"
cp -r "$SRC_DIR/launch.sh" "$TARGET_DIR/"
chmod +x "$TARGET_DIR/launch.sh" "$TARGET_DIR/douyu_monitor_native"

# 图标安装
if [ -d "$SRC_DIR/icons" ]; then
    for size in 16 24 32 48 64 128 256 512; do
        if [ -f "$SRC_DIR/icons/${size}x${size}/douyu-monitor.png" ]; then
            dest="$HOME/.local/share/icons/hicolor/${size}x${size}/apps"
            mkdir -p "$dest"
            cp "$SRC_DIR/icons/${size}x${size}/douyu-monitor.png" "$dest/"
        fi
    done
    gtk-update-icon-cache -f -t "$HOME/.local/share/icons/hicolor" 2>/dev/null || true
fi

# 桌面快捷方式
DESKTOP_DIR="$HOME/.local/share/applications"
mkdir -p "$DESKTOP_DIR"
cat > "$DESKTOP_DIR/douyu-monitor.desktop" << DESK
[Desktop Entry]
Version=1.0
Type=Application
Name=斗鱼监控
GenericName=Douyu Monitor
Comment=斗鱼多路直播监控客户端
Exec=$TARGET_DIR/launch.sh %U
Icon=douyu-monitor
Terminal=false
Categories=AudioVideo;Player;
Keywords=douyu;monitor;live;stream;tv;斗鱼;直播;监控;
StartupNotify=true
StartupWMClass=douyu_monitor_native
DESK
chmod +x "$DESKTOP_DIR/douyu-monitor.desktop"

if [ -d "$HOME/桌面" ]; then
    cp "$DESKTOP_DIR/douyu-monitor.desktop" "$HOME/桌面/"
    chmod +x "$HOME/桌面/douyu-monitor.desktop"
    gio set "$HOME/桌面/douyu-monitor.desktop" metadata::trusted true 2>/dev/null || true
elif [ -d "$HOME/Desktop" ]; then
    cp "$DESKTOP_DIR/douyu-monitor.desktop" "$HOME/Desktop/"
    chmod +x "$HOME/Desktop/douyu-monitor.desktop"
    gio set "$HOME/Desktop/douyu-monitor.desktop" metadata::trusted true 2>/dev/null || true
fi

update-desktop-database "$HOME/.local/share/applications/" 2>/dev/null || true
echo "安装成功！已在应用菜单和桌面创建快捷方式。"
