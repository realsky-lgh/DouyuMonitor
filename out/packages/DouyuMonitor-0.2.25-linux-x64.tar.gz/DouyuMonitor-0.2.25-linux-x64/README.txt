====================================
斗鱼监控 (DouyuMonitor) Linux 便携版
版本: v0.2.25
====================================

一、直接运行 (无需安装):
  直接在终端执行:
    ./launch.sh

二、一键安装到系统应用菜单与桌面快捷方式:
  在终端执行:
    ./install.sh
  完成后即可在系统应用程序菜单或桌面双击启动。

三、卸载:
  执行:
    ./uninstall.sh

四、运行依赖要求:
  1. Qt 6 (6.4+) 运行库:
     - Ubuntu/Debian: sudo apt install libqt6quick6 libqt6qml6 libqt6core6 libqt6websockets6 qml6-module-qtquick-controls
     - Arch Linux: sudo pacman -S qt6-base qt6-declarative qt6-websockets
     - Fedora: sudo dnf install qt6-qtbase qt6-qtdeclarative qt6-qtwebsockets
  2. mpv 视频解码核心:
     - Ubuntu/Debian: sudo apt install libmpv2 或 libmpv1
     - Arch Linux: sudo pacman -S mpv
     - Fedora: sudo dnf install mpv-libs
